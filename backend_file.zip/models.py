"""
models.py

SQLAlchemy models for the application.
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base


class User(Base):
    """Represents an application user.

    Fields:
    - id: primary key
    - name: display name
    - email: unique email address
    - hashed_password: bcrypt-hashed password
    - created_at: timestamp when the user was created
    """
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Scan(Base):
    """Represents a freshness analysis scan performed by a user.

    Fields:
    - id: primary key
    - user_id: foreign key to `users.id`
    - product_name: name of the produce item
    - freshness_score: integer 0-100 (higher is fresher)
    - shelf_life_days: estimated days before spoilage
    - defects: comma-separated short descriptions
    - recommendation: optional text provided by a decision agent later
    - reasoning: optional JSON-encoded list of short explanation strings
    - created_at: timestamp when the scan was performed
    """
    __tablename__ = "scans"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    product_name = Column(String, nullable=False)
    freshness_score = Column(Integer, nullable=False)
    shelf_life_days = Column(Integer, nullable=False)
    defects = Column(Text, nullable=False)
    recommendation = Column(Text, nullable=True)
    reasoning = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # relationship back to the user for convenience
    user = relationship("User", backref="scans")
